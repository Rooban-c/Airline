package flight.app.exceptionHandler;

public class AdminInvalidCredentialsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminInvalidCredentialsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AdminInvalidCredentialsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AdminInvalidCredentialsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AdminInvalidCredentialsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public AdminInvalidCredentialsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
