package flight.app.entities;

public class UserDetails {

	//Default values for faster booking.
	
	
}
